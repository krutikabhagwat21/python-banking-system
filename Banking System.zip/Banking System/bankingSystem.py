"""
=================================================
     BANKING SYSTEM — Simple Python Version
=================================================
Features:
  - Savings, Current, Fixed Deposit accounts
  - Deposit, Withdraw, Transfer, History
  - PIN security with SHA-256 hashing
  - Daily limits, minimum balance rules
  - Interest calculation
  - Analytics (top accounts, totals, search)
=================================================
"""

import hashlib
import datetime
import random
import string

#  SETTINGS

BANK_NAME    = "PyBank India"
MIN_BALANCE  = 500.0       # minimum balance to keep in account
MAX_WITHDRAW = 50000.0     # max single withdrawal

INTEREST_RATES = {
    "savings": 0.04,       # 4% per year
    "current": 0.01,       # 1% per year
    "fd":      0.07,       # 7% per year
}

DAILY_LIMITS = {
    "savings": 25000.0,    # max per day for savings
    "current": 100000.0,   # max per day for current
    "fd":      0.0,        # no withdrawal for FD
}

#  HELPER FUNCTIONS
def hash_pin(pin):
    """Convert PIN to a secure hash so raw PIN is never stored."""
    return hashlib.sha256(pin.encode()).hexdigest()


def make_account_number():
    """Generate a random account number like PB1234567890."""
    prefix = random.choice(["PB", "SB", "CB", "GB"])
    digits = "".join(random.choices(string.digits, k=10))
    return prefix + digits


def make_transaction_id():
    """Generate a random transaction ID like T123456789."""
    return "T" + "".join(random.choices(string.digits, k=9))


def line(char="═", length=60):
    """Print a separator line."""
    print(char * length)


def header(title):
    """Print a section header."""
    print()
    line()
    print("  " + title)
    line()


def pause():
    """Wait for user to press Enter."""
    input("\n  Press Enter to continue...")


#  TRANSACTION — one record of money movement
class Transaction:
    """
    Stores one transaction — deposit, withdrawal, etc.
    Once created, values never change.
    """

    def __init__(self, txn_type, amount, balance_after, note=""):
        self.txn_id       = make_transaction_id()
        self.txn_type     = txn_type        # "deposit", "withdrawal", etc.
        self.amount       = round(amount, 2)
        self.balance_after = round(balance_after, 2)
        self.note         = note
        self.timestamp    = datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S")

    def is_credit(self):
        """Returns True if money came IN."""
        credit_types = ["deposit", "transfer_in", "interest", "initial"]
        return self.txn_type in credit_types

    def display(self):
        """Print this transaction in a readable format."""
        direction = "CR" if self.is_credit() else "DR"
        print(f"  [{self.timestamp}]  {self.txn_id}  "
              f"{direction}  {self.txn_type.upper():<14}  "
              f"Rs {self.amount:>10,.2f}  |  "
              f"Bal: Rs {self.balance_after:>10,.2f}"
              + (f"  ({self.note})" if self.note else ""))


#  ACCOUNT — holds money and transaction list
class Account:
    """
    One bank account.
    Stores owner info, balance, and transaction history.
    """

    def __init__(self, owner, phone, pin, acc_type, opening_amount):

        # basic validation
        if len(phone) != 10 or not phone.isdigit():
            print("  Error: Phone must be exactly 10 digits.")
            return

        if not (4 <= len(pin) <= 6) or not pin.isdigit():
            print("  Error: PIN must be 4 to 6 digits.")
            return

        if opening_amount < MIN_BALANCE:
            print(f"  Error: Opening amount must be at least Rs {MIN_BALANCE:.0f}.")
            return

        # store account info
        self.account_no   = make_account_number()
        self.owner        = owner
        self.phone        = phone
        self.acc_type     = acc_type          # "savings", "current", "fd"
        self.pin_hash     = hash_pin(pin)     # store hash, not actual PIN
        self.balance      = 0.0
        self.is_active    = True
        self.transactions = []                # list of Transaction objects

        # daily withdrawal tracking 
        self.daily_limit       = DAILY_LIMITS.get(acc_type, 20000.0)
        self.daily_used        = 0.0
        self.daily_reset_date  = datetime.date.today()

        # add the opening deposit
        self.balance = opening_amount
        txn = Transaction("initial", opening_amount, self.balance, "Account opening")
        self.transactions.append(txn)

    #  PIN check

    def check_pin(self, pin):
        """Returns True if the entered PIN matches."""
        return self.pin_hash == hash_pin(pin)

    def change_pin(self, old_pin, new_pin):
        """Change PIN after verifying the old one."""
        if not self.check_pin(old_pin):
            print("  Error: Wrong current PIN.")
            return False
        if not (4 <= len(new_pin) <= 6) or not new_pin.isdigit():
            print("  Error: New PIN must be 4 to 6 digits.")
            return False
        if old_pin == new_pin:
            print("  Error: New PIN must be different.")
            return False
        self.pin_hash = hash_pin(new_pin)
        print("  PIN changed successfully.")
        return True
    
    #  Daily limit reset
    def reset_daily_if_new_day(self):
        """If today is a new day, reset the daily withdrawal counter."""
        today = datetime.date.today()
        if self.daily_reset_date != today:
            self.daily_used = 0.0
            self.daily_reset_date = today

    #  DEPOSIT
    def deposit(self, amount, note=""):
        """Add money to the account."""

        # check account is active
        if not self.is_active:
            print("  Error: Account is frozen.")
            return False

        # check amount is valid
        if amount <= 0:
            print("  Error: Amount must be positive.")
            return False

        if amount > 1000000:
            print("  Error: Single deposit limit is Rs 10,00,000.")
            return False

        # add money
        self.balance = round(self.balance + amount, 2)

        # record the transaction
        txn = Transaction("deposit", amount, self.balance, note or "Cash deposit")
        self.transactions.append(txn)

        print(f"  Deposited Rs {amount:,.2f}. New balance: Rs {self.balance:,.2f}")
        return True

    #  WITHDRAW
    def withdraw(self, amount, note=""):
        """Take money out of the account."""

        # check account is active
        if not self.is_active:
            print("  Error: Account is frozen.")
            return False

        # FD accounts cannot withdraw
        if self.acc_type == "fd":
            print("  Error: FD accounts cannot withdraw before maturity.")
            return False

        # check amount is valid
        if amount <= 0:
            print("  Error: Amount must be positive.")
            return False

        # check single transaction limit
        if amount > MAX_WITHDRAW:
            print(f"  Error: Single withdrawal limit is Rs {MAX_WITHDRAW:,.0f}.")
            return False

        # reset daily counter if it's a new day
        self.reset_daily_if_new_day()

        # check daily limit
        if self.daily_limit > 0:
            if self.daily_used + amount > self.daily_limit:
                remaining = self.daily_limit - self.daily_used
                print(f"  Error: Daily limit exceeded. Remaining today: Rs {remaining:,.2f}")
                return False

        # check minimum balance will be maintained
        if self.balance - amount < MIN_BALANCE:
            print(f"  Error: Must keep minimum Rs {MIN_BALANCE:,.0f} in account.")
            return False

        # all checks passed — take the money
        self.daily_used += amount
        self.balance = round(self.balance - amount, 2)

        # record the transaction
        txn = Transaction("withdrawal", amount, self.balance, note or "Cash withdrawal")
        self.transactions.append(txn)

        print(f"  Withdrew Rs {amount:,.2f}. New balance: Rs {self.balance:,.2f}")
        return True

    #  INTEREST
    def add_interest(self):
        """Add one month of interest to the account."""
        rate    = INTEREST_RATES.get(self.acc_type, 0.0)
        monthly = round(self.balance * rate / 12, 2)
        self.balance = round(self.balance + monthly, 2)

        txn = Transaction("interest", monthly, self.balance,
                          f"Monthly interest @ {rate*100:.1f}% p.a.")
        self.transactions.append(txn)

        print(f"  Interest Rs {monthly:,.2f} added. Balance: Rs {self.balance:,.2f}")

    #  FREEZE / UNFREEZE
    def freeze(self):
        self.is_active = False
        print(f"  Account {self.account_no} is now frozen.")

    def unfreeze(self):
        self.is_active = True
        print(f"  Account {self.account_no} is now active.")

    #  SHOW ACCOUNT DETAILS
    def show_details(self):
        """Print account summary."""
        status = "ACTIVE" if self.is_active else "FROZEN"
        masked_phone = "*" * 6 + self.phone[-4:]
        print(f"  Account No   : {self.account_no}")
        print(f"  Owner        : {self.owner}")
        print(f"  Phone        : {masked_phone}")
        print(f"  Type         : {self.acc_type.upper()}")
        print(f"  Balance      : Rs {self.balance:,.2f}")
        print(f"  Transactions : {len(self.transactions)}")
        print(f"  Status       : {status}")

    #  SHOW HISTORY
    def show_history(self, last_n=None):
        """Print transaction history, newest first."""
        all_txns = list(reversed(self.transactions))   # newest first
        if last_n:
            all_txns = all_txns[:last_n]
        if not all_txns:
            print("  No transactions yet.")
            return
        for txn in all_txns:
            txn.display()
        print(f"\n  Total transactions: {len(self.transactions)}")

    def show_history_by_type(self, txn_type):
        """Print only transactions of a certain type."""
        matching = [t for t in self.transactions if t.txn_type == txn_type]
        if not matching:
            print(f"  No {txn_type} transactions found.")
            return
        for txn in matching:
            txn.display()
        print(f"\n  Found {len(matching)} transaction(s).")


#  SAVINGS ACCOUNT — extra: ATM card
class SavingsAccount(Account):
    """Savings account — has ATM card feature."""

    def __init__(self, owner, phone, pin, amount):
        super().__init__(owner, phone, pin, "savings", amount)
        self.atm_card = False

    def issue_atm_card(self):
        """Issue an ATM card to this account."""
        self.atm_card = True
        card = "**** **** **** " + "".join(random.choices(string.digits, k=4))
        print(f"  ATM Card issued: {card}")

    def show_details(self):
        super().show_details()
        print(f"  ATM Card     : {'Yes' if self.atm_card else 'No'}")


#  CURRENT ACCOUNT — extra: overdraft
class CurrentAccount(Account):
    """Current account — can go slightly below zero (overdraft)."""

    OVERDRAFT_LIMIT = 50000.0

    def __init__(self, owner, phone, pin, amount):
        super().__init__(owner, phone, pin, "current", amount)
        self.overdraft_used = 0.0

    def withdraw(self, amount, note=""):
        """
        Current account can use overdraft.
        Available = balance + remaining overdraft.
        """
        if not self.is_active:
            print("  Error: Account is frozen.")
            return False

        if amount <= 0:
            print("  Error: Amount must be positive.")
            return False

        # calculate how much can be withdrawn including overdraft
        overdraft_remaining = self.OVERDRAFT_LIMIT - self.overdraft_used
        available = self.balance + overdraft_remaining

        if amount > available:
            print(f"  Error: Cannot withdraw. Available (with overdraft): Rs {available:,.2f}")
            return False

        # if withdrawal goes into overdraft, track it
        if amount > self.balance:
            into_overdraft = amount - self.balance
            self.overdraft_used += into_overdraft

        # reset daily counter if new day
        self.reset_daily_if_new_day()

        # check daily limit
        if self.daily_used + amount > self.daily_limit:
            remaining = self.daily_limit - self.daily_used
            print(f"  Error: Daily limit exceeded. Remaining: Rs {remaining:,.2f}")
            return False

        # do the withdrawal
        self.daily_used += amount
        self.balance = round(self.balance - amount, 2)

        txn = Transaction("withdrawal", amount, self.balance, note or "Cash withdrawal")
        self.transactions.append(txn)

        print(f"  Withdrew Rs {amount:,.2f}. New balance: Rs {self.balance:,.2f}")
        return True

    def show_details(self):
        super().show_details()
        overdraft_left = self.OVERDRAFT_LIMIT - self.overdraft_used
        print(f"  Overdraft    : Rs {overdraft_left:,.2f} available")


#  FD ACCOUNT — no withdrawal before maturity
class FDAccount(Account):
    """Fixed Deposit — cannot withdraw until maturity date."""

    def __init__(self, owner, phone, pin, amount, months=12):
        super().__init__(owner, phone, pin, "fd", amount)
        self.months = months
        self.maturity_date = datetime.date.today() + datetime.timedelta(days=months * 30)

    def withdraw(self, amount, note=""):
        """FD cannot withdraw — always blocked."""
        print(f"  Error: No withdrawal allowed. Maturity date: {self.maturity_date}")
        return False

    def show_details(self):
        super().show_details()
        print(f"  Maturity     : {self.maturity_date} ({self.months} months)")


#  BANK — manages all accounts
class Bank:
    """
    The main bank — stores all accounts in a dictionary.
    Key = account number, Value = Account object.
    """

    def __init__(self, name=BANK_NAME):
        self.name     = name
        self.accounts = {}    # { "PB1234567890": Account object }

    #  OPEN ACCOUNTS
    def open_savings(self, owner, phone, pin, amount):
        acc = SavingsAccount(owner, phone, pin, amount)
        self.accounts[acc.account_no] = acc
        return acc

    def open_current(self, owner, phone, pin, amount):
        acc = CurrentAccount(owner, phone, pin, amount)
        self.accounts[acc.account_no] = acc
        return acc

    def open_fd(self, owner, phone, pin, amount, months=12):
        acc = FDAccount(owner, phone, pin, amount, months)
        self.accounts[acc.account_no] = acc
        return acc

    #  FIND ACCOUNT
    def find_account(self, account_no):
        """Return account or None if not found."""
        return self.accounts.get(account_no.upper())

    #  TRANSFER MONEY
    def transfer(self, from_no, to_no, amount, pin):
        """Transfer money from one account to another."""
        # find both accounts
        src  = self.find_account(from_no)
        dest = self.find_account(to_no)

        if src is None:
            print(f"  Error: Source account {from_no} not found.")
            return False

        if dest is None:
            print(f"  Error: Destination account {to_no} not found.")
            return False

        # verify PIN
        if not src.check_pin(pin):
            print("  Error: Wrong PIN.")
            return False

        if amount <= 0:
            print("  Error: Transfer amount must be positive.")
            return False

        # check minimum balance (source keeps MIN_BALANCE)
        if src.balance - amount < MIN_BALANCE:
            print(f"  Error: Source account must keep Rs {MIN_BALANCE:,.0f} minimum.")
            return False

        # do the transfer
        src.balance = round(src.balance - amount, 2)
        dest.balance = round(dest.balance + amount, 2)

        # record in both accounts
        txn_out = Transaction("transfer_out", amount, src.balance,
                              f"Transfer to {to_no}")
        txn_in  = Transaction("transfer_in",  amount, dest.balance,
                              f"Transfer from {from_no}")
        src.transactions.append(txn_out)
        dest.transactions.append(txn_in)

        print(f"  Rs {amount:,.2f} transferred from {from_no} to {to_no}.")
        return True

    #  APPLY INTEREST TO ALL ACCOUNTS
    def apply_interest_all(self):
        """Add monthly interest to all savings and FD accounts."""
        count = 0
        for acc in self.accounts.values():
            if acc.acc_type in ("savings", "fd") and acc.is_active:
                acc.add_interest()
                count += 1
        if count == 0:
            print("  No eligible accounts.")
        else:
            print(f"  Interest applied to {count} account(s).")

    #  ANALYTICS
    def total_money(self):
        """Sum of all balances across all accounts."""
        total = 0
        for acc in self.accounts.values():
            total += acc.balance
        return round(total, 2)

    def top_accounts(self, n=3):
        """Return the top N accounts by balance."""
        all_accounts = list(self.accounts.values())
        # sort by balance from high to low
        all_accounts.sort(key=lambda a: a.balance, reverse=True)
        return all_accounts[:n]

    def search_by_name(self, name_fragment):
        """Find all accounts where owner name contains the fragment."""
        results = []
        for acc in self.accounts.values():
            if name_fragment.lower() in acc.owner.lower():
                results.append(acc)
        return results

    def count_by_type(self):
        """Count how many accounts of each type exist."""
        counts = {"savings": 0, "current": 0, "fd": 0}
        totals = {"savings": 0.0, "current": 0.0, "fd": 0.0}
        for acc in self.accounts.values():
            counts[acc.acc_type] = counts.get(acc.acc_type, 0) + 1
            totals[acc.acc_type] = totals.get(acc.acc_type, 0.0) + acc.balance
        return counts, totals

    def show_all_accounts(self):
        """Print a summary of every account sorted by balance."""
        all_accounts = list(self.accounts.values())
        all_accounts.sort(key=lambda a: a.balance, reverse=True)
        for acc in all_accounts:
            status = "Active" if acc.is_active else "Frozen"
            print(f"  {acc.account_no}  {acc.owner:<22}  "
                  f"{acc.acc_type:<10}  Rs {acc.balance:>10,.2f}  "
                  f"Txns:{len(acc.transactions)}  [{status}]")
        print(f"\n  Total accounts: {len(self.accounts)}")

    def show_summary(self):
        """Print bank-wide summary."""
        counts, totals = self.count_by_type()
        active = sum(1 for a in self.accounts.values() if a.is_active)
        print(f"\n  Bank        : {self.name}")
        print(f"  Accounts    : {len(self.accounts)}  (Active: {active})")
        print(f"  Total Money : Rs {self.total_money():,.2f}")
        print()
        print(f"  {'Type':<12} {'Count':>5}  {'Total Balance':>16}")
        print("  " + "-" * 38)
        for t in ("savings", "current", "fd"):
            print(f"  {t.upper():<12} {counts.get(t,0):>5}  "
                  f"Rs {totals.get(t,0):>12,.2f}")


#  MAIN PROGRAM — the menu system
def main():
    bank = Bank()

    # create 3 demo accounts for testing
    s = bank.open_savings( "Priya Sharma",  "9876543210", "1111", 15000)
    c = bank.open_current( "Rahul Gupta",   "9123456780", "2222", 50000)
    f = bank.open_fd(      "Anjali Verma",  "9988776655", "3333", 25000, 12)
    s.deposit(10000, "Salary")
    c.deposit(30000, "Business income")
    bank.transfer(c.account_no, s.account_no, 5000, "2222")

    print("\n" + "=" * 60)
    print(f"  Welcome to {bank.name}")
    print(f"  {datetime.datetime.now().strftime('%A, %d %B %Y  %H:%M')}")
    print("=" * 60)
    print("  Demo accounts ready:")
    print(f"  Savings  : {s.account_no}  PIN: 1111")
    print(f"  Current  : {c.account_no}  PIN: 2222")
    print(f"  FD       : {f.account_no}  PIN: 3333")
    print("=" * 60)

    # main loop 
    while True:
        header("MAIN MENU")
        print("  [1] Open New Account")
        print("  [2] Login to Account")
        print("  [3] Transfer Money")
        print("  [4] Bank Summary")
        print("  [5] Apply Monthly Interest")
        print("  [6] Search by Name")
        print("  [7] View All Accounts")
        print("  [0] Exit")
        choice = input("\n  Choice: ").strip()

        # OPEN ACCOUNT
        if choice == "1":
            header("OPEN NEW ACCOUNT")
            name  = input("  Full Name          : ").strip()
            phone = input("  Phone (10 digits)  : ").strip()
            pin   = input("  Set PIN (4-6 digit): ").strip()
            print("  Type: [1] Savings  [2] Current  [3] Fixed Deposit")
            acc_choice = input("  Choose: ").strip()

            try:
                amount = float(input(f"  Opening Amount (min Rs {MIN_BALANCE:.0f}): "))
            except ValueError:
                print("  Invalid amount.")
                pause()
                continue

            if acc_choice == "1":
                acc = bank.open_savings(name, phone, pin, amount)
                print(f"\n  Savings account opened!")
                print(f"  Account No: {acc.account_no}")

            elif acc_choice == "2":
                acc = bank.open_current(name, phone, pin, amount)
                print(f"\n  Current account opened!")
                print(f"  Account No: {acc.account_no}")

            elif acc_choice == "3":
                try:
                    months = int(input("  Duration (months, default 12): ") or "12")
                except ValueError:
                    months = 12
                acc = bank.open_fd(name, phone, pin, amount, months)
                print(f"\n  FD account opened!")
                print(f"  Account No: {acc.account_no}")

            else:
                print("  Invalid choice.")

        # LOGIN 
        elif choice == "2":
            header("LOGIN")
            account_no = input("  Account Number: ").strip().upper()
            pin        = input("  PIN           : ").strip()

            acc = bank.find_account(account_no)

            if acc is None:
                print("  Account not found.")
                pause()
                continue

            if not acc.check_pin(pin):
                print("  Wrong PIN.")
                pause()
                continue

            if not acc.is_active:
                print("  Account is frozen.")
                pause()
                continue

            print(f"\n  Welcome, {acc.owner}!")
            logged_in = True

            # account sub-menu
            while logged_in:
                header(f"ACCOUNT: {acc.account_no}   Balance: Rs {acc.balance:,.2f}")
                print("  [1] Deposit")
                print("  [2] Withdraw")
                print("  [3] Mini Statement (last 5)")
                print("  [4] Full Statement")
                print("  [5] Statement by Type")
                print("  [6] Add Interest")
                print("  [7] Change PIN")
                print("  [8] Issue ATM Card")
                print("  [9] Account Details")
                print("  [0] Logout")
                ac = input("\n  Choice: ").strip()

                if ac == "1":
                    try:
                        amount = float(input("  Amount: Rs "))
                        note   = input("  Note (optional): ")
                        acc.deposit(amount, note)
                    except ValueError:
                        print("  Invalid amount.")

                elif ac == "2":
                    try:
                        amount = float(input("  Amount: Rs "))
                        note   = input("  Note (optional): ")
                        acc.withdraw(amount, note)
                    except ValueError:
                        print("  Invalid amount.")

                elif ac == "3":
                    print()
                    line("-")
                    print("  MINI STATEMENT — Last 5 transactions")
                    line("-")
                    acc.show_history(last_n=5)

                elif ac == "4":
                    print()
                    line("-")
                    print("  FULL STATEMENT")
                    line("-")
                    acc.show_history()

                elif ac == "5":
                    types = ["deposit", "withdrawal", "transfer_in",
                             "transfer_out", "interest", "initial"]
                    for i, t in enumerate(types, 1):
                        print(f"  [{i}] {t}")
                    tn = input("  Choose type: ").strip()
                    if tn.isdigit() and 1 <= int(tn) <= len(types):
                        chosen = types[int(tn) - 1]
                        print(f"\n  {chosen.upper()} transactions:")
                        line("-")
                        acc.show_history_by_type(chosen)

                elif ac == "6":
                    acc.add_interest()

                elif ac == "7":
                    old = input("  Current PIN: ")
                    new = input("  New PIN    : ")
                    acc.change_pin(old, new)

                elif ac == "8":
                    if isinstance(acc, SavingsAccount):
                        acc.issue_atm_card()
                    else:
                        print("  ATM card is only for Savings accounts.")

                elif ac == "9":
                    print()
                    line("-")
                    acc.show_details()
                    line("-")

                elif ac == "0":
                    print("  Logged out.")
                    logged_in = False

                else:
                    print("  Invalid choice.")

                if logged_in:
                    pause()

        # TRANSFER 
        elif choice == "3":
            header("TRANSFER MONEY")
            from_no = input("  From Account No : ").strip().upper()
            to_no   = input("  To Account No   : ").strip().upper()
            try:
                amount = float(input("  Amount: Rs "))
            except ValueError:
                print("  Invalid amount.")
                pause()
                continue
            pin = input("  Your PIN        : ").strip()
            bank.transfer(from_no, to_no, amount, pin)

        #  BANK SUMMARY
        elif choice == "4":
            header("BANK SUMMARY")
            bank.show_summary()
            print()
            print("  Top 3 Accounts by Balance:")
            line("-")
            for i, acc in enumerate(bank.top_accounts(3), 1):
                print(f"  {i}. {acc.owner:<22}  {acc.account_no}  "
                      f"Rs {acc.balance:,.2f}")

        # APPLY INTEREST 
        elif choice == "5":
            header("APPLY MONTHLY INTEREST")
            confirm = input("  Apply to all savings and FD accounts? (yes/no): ")
            if confirm.lower() == "yes":
                bank.apply_interest_all()

        #  SEARCH BY NAME
        elif choice == "6":
            header("SEARCH BY NAME")
            name_frag = input("  Enter name or part of name: ").strip()
            results   = bank.search_by_name(name_frag)
            if results:
                print(f"\n  Found {len(results)} account(s):")
                line("-")
                for acc in results:
                    print(f"  {acc.account_no}  {acc.owner:<22}  "
                          f"{acc.acc_type:<10}  Rs {acc.balance:,.2f}")
            else:
                print("  No accounts found.")

        # VIEW ALL ACCOUNTS 
        elif choice == "7":
            header("ALL ACCOUNTS")
            bank.show_all_accounts()

        #  EXIT 
        elif choice == "0":
            print(f"\n  Thank you for using {bank.name}. Goodbye!\n")
            break

        else:
            print("  Invalid choice. Please try again.")

        pause()


if __name__ == "__main__":
    main()